package com.sun.tools.javadoc;

public class Main
{
	 public static void main(String[] args)
	 {
	 	gnu.classpath.tools.gjdoc.Main.main(args);
	 }
}
